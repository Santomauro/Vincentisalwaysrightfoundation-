# Vincent’s Monument of Truth

This is a satirical website dedicated to the undeniable truth that Vincent is always right.

## How to Deploy on GitHub Pages

1. Fork this repository to your GitHub account.
2. Go to **Settings** > **Pages**.
3. Under "Source," select **main branch**.
4. Your site will be live at `https://hexagon.github.io/`.

## Features

- About page explaining Vincent's wisdom.
- Monument tribute to Vincent’s correctness.
- Testimonials from believers.
- FAQ section answering common doubts.
- Contact form & donation page.

Enjoy the correctness!
